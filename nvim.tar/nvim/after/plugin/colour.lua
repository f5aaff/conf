vim.cmd.colorscheme "catppuccin"
